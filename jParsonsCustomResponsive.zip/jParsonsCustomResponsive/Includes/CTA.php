<div class="siteCTAWrap">

  <div class="CTAWrapOverlay">

      <div class="CTAcontent">

        <h3 class="whiteText">Ready to start giving your car the expert care that it deserves?</h3>

          <p class="whiteText">

            Don't put it off any longer. Stop in or contact Arden's Automotive Hospital to set up an appointment for your vehicle today.

          </p>


          <div class="centeredButton">

            <a href="/contact/" class="whiteButton" role="link">Contact Arden's</a>

          </div>

      </div>

  </div>

</div>
