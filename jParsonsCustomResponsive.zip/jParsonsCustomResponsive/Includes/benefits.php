<div class="flex-container cardWrap">

  <div class="col30">

    <div class="raisedTextBox">

      <div class="textWrap">

        <h3 class="centerText">Trustworthy and Reliable</h3>

        <p>No matter how big or small the issue, you’ll find a professional and honest opinion for all your auto repairs.</p>

      </div>

    </div>

  </div>
  <div class="col30">

    <div class="raisedTextBox">

      <div class="textWrap">

        <h3 class="centerText">Family Oriented</h3>

        <p>You’ll always be treated as a part of our family. Now in our third generation of ownership, family values run true here at Arden’s.</p>

      </div>

    </div>

  </div>
  <div class="col30">

    <div class="raisedTextBox">

      <div class="textWrap">

        <h3 class="centerText">Fair</h3>

        <p>Your car is important to you so it’s important to us as well, at Arden’s you’ll always get a fair price to get your car back on the road.</p>

      </div>

    </div>

  </div>

</div>
